# Employee-Management-System
This repository consists of Java Program for Employee Management System. In this repository I have created a TUI program for Employee Management System which consists of 4 different operation.<br>
(1) Adding User<br>  (2) Removing User<br> (3) Updating User<br>  (4) Viewing details of User

The Program is completely based on OOPs concept.

<img src="Images/Java.png">

# How to run ?
For Compliation : <code>javac EmployManagementSystem.java</code>

To Run Program  : <code>java EmployManagementSystem</code>
